create view MONITEURS_CONFIRMES as
SELECT 
        CDMONO,
        NOM,
        PRNM,
        STATUT,
        IND
    FROM
        MONITEUR M
    WHERE
        EXISTS (SELECT  NULL
                FROM    STAGE S
                WHERE   M.CDMONO = CDMONO
                        AND CDTPSTAGE = (   SELECT  CDTPSTAGE
                                            FROM    TYPESTAGE
                                            WHERE   UPPER(LIBTPSTAGE) LIKE 'BAPT%'))
        AND RESPONSABLE IS NULL
/

